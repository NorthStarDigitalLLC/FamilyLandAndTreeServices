# GitHub Pages Website

Upload these files to the root of your repository.

Files included:
- index.html
- styles.css
- script.js
- .nojekyll

Enable GitHub Pages:

Settings → Pages
Source: Deploy from branch
Branch: main
Folder: /(root)

Then open:

https://YOUR-USERNAME.github.io/REPOSITORY-NAME/
