
const year=document.getElementById("year");
if(year){year.textContent=new Date().getFullYear();}

const themeBtn=document.getElementById("themeBtn");
if(themeBtn){
themeBtn.addEventListener("click",()=>{
document.body.classList.toggle("dark");
});
}

const form=document.getElementById("contactForm");
const status=document.getElementById("status");

if(form){
form.addEventListener("submit",(e)=>{
e.preventDefault();

const name=document.getElementById("name").value.trim();
const email=document.getElementById("email").value.trim();
const message=document.getElementById("message").value.trim();

if(!name||!email||!message){
status.textContent="Please fill all fields.";
return;
}

status.textContent="Message submitted!";
form.reset();
});
}
