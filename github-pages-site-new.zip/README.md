# Simple GitHub Pages Website

Files:
- index.html
- styles.css
- script.js

## Deploy

1. Create a GitHub repository
2. Upload these files
3. Go to Settings → Pages
4. Select Deploy from branch
5. Choose main / root
